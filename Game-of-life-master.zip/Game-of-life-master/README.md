This repository contains a sipmple terminalbased game of life, with 2 classes and a mainfile all written i Python, the two classes are the cells wich will fill the board. The second class (spillbrett.py) is the main gameboard, wich contains all the methods for the rules, update, and initialization of the board.
 
